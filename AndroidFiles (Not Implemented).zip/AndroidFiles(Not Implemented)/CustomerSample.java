package com.example.barbershopapp;


    public class CustomerSample{
        public String type;
        public String name;
        public String username;
        public String email;
        public Long phone;
        public String password;
        public Long userID;

        CustomerSample(Long userID, String type, String username,  String email, Long phone, String password) {
            this.userID = userID;
            this.type = type;
            this.username = username;
            this.email = email;
            this.phone = phone;
            this.password = password;
        }
}
