package com.example.barbershopapp;
import android.support.v7.app.AppCompatActivity;
import java.util.*;
import android.os.Bundle;
import android.widget.Button;
import android.util.Log;
import android.view.View;
import android.content.Intent;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import android.graphics.Color;
import java.io.*;
import java.util.Scanner;



public class Signup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        Button mButton = findViewById(R.id.login_redirect);
        mButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Signup.this, Login.class);
                startActivity(intent);
            }
        });

        Button mSignupButton = findViewById(R.id.signup_submit);
        final TextView mUsername = findViewById(R.id.username);
        final TextView mEmail = findViewById(R.id.email);
        final TextView mPassword = findViewById(R.id.password);
        TextView mPassword2 = findViewById(R.id.password_2);
        final TextView mPhone = findViewById(R.id.phone);
        Spinner mySpinner = (Spinner) findViewById(R.id.spinner1);
        final String type = "Customer";
                //mySpinner.getSelectedItem().toString();
        final long number = (long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
        final TextView mSignupMessage = findViewById(R.id.signup_message);
        final TextView mDesiredShopID = findViewById(R.id.desired_shop_id);



        mSignupButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


//                Log.d("MyTagGoesHere", "Username Value: " + mUsername.getText().toString());
//                int value;
                String firebaseType;

//
//                int manualValue = 2;
//
//                GetServer getServer = new GetServer();
//                CustomerInfo info = new CustomerInfo("Phil", mUsername.getText().toString(), "philberhane@yahoo.com", 7073150270L, mPassword.getText().toString());
//                getServer.createCustomerInfoAccount(info);
//
//                System.out.println(getServer.getCustomerInfo( mUsername.getText().toString(), mPassword.getText().toString()));
//
//
                try {

                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference ref = database.getReference("server/saving-data/users");
                    if (type == "Customer") {
                        //firebaseType = "Customers";
                        CustomerSample users = new CustomerSample(number,"Customer", mUsername.getText().toString(), mEmail.getText().toString(), Long.parseLong(mPhone.getText().toString()), mPassword.getText().toString());
                        ref.child(mUsername.getText().toString()).setValue(users);
                        mSignupMessage.setTextColor(Color.BLUE);
                        mSignupMessage.setText("You have successfully signed up, please log in!");
                    }else if (type == "Barber"){
                        //firebaseType = "Barbers";
                        BarberSample users = new BarberSample(number,"Barber", mUsername.toString(), mEmail.toString(), Long.parseLong(mPhone.toString()), mPassword.toString(), "Available", Long.parseLong(mDesiredShopID.toString()));
                        ref.child(mUsername.getText().toString()).setValue(users);
                        mSignupMessage.setTextColor(Color.BLUE);
                        mSignupMessage.setText("You have successfully signed up, please log in!");
                    } else {
                        firebaseType = "Barbershops";
                    }


                } catch (Exception e) {
                    mSignupMessage.setTextColor(Color.RED);
                    mSignupMessage.setText("There was an error, please try again!");
                }





            }
        });

        Spinner spinner = (Spinner) findViewById(R.id.spinner1);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.user_types, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

    }
}
