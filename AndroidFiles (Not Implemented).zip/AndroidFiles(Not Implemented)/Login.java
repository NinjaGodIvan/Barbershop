package com.example.barbershopapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.util.Log;
import android.view.View;
import android.content.Intent;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.Query;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import android.graphics.Color;
import android.widget.TextView;


public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        Button mButton = findViewById(R.id.signup_redirect);
        mButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Write a message to the database


                Log.d("myTag", "This is my message");
                Intent intent = new Intent(Login.this, Signup.class);
                startActivity(intent);
            }
        });

        Button mLoginButton = findViewById(R.id.login_submit);
        mLoginButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final TextView mUsername = findViewById(R.id.user_name);
                final TextView mPassword = findViewById(R.id.password);
                // Write a message to the database
                DatabaseReference mDatabaseReference = FirebaseDatabase.getInstance().getReference("server/saving-data/users");

                //System.out.println(query);

                mDatabaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        if (dataSnapshot.child(mUsername.getText().toString()).exists()){
                           // System.out.println(dataSnapshot.child("Phil").child("password").getValue());
                            if (dataSnapshot.child(mUsername.getText().toString()).child("password").getValue().equals(mPassword.getText().toString()) ) {

                                if (dataSnapshot.child(mUsername.getText().toString()).child("type").getValue().equals("Customer")) {
                                    Intent intent = new Intent(Login.this, CustomerDashboard.class);
                                    intent.putExtra("username", mUsername.getText().toString());
                                    startActivity(intent);
                                }
                                if (dataSnapshot.child(mUsername.getText().toString()).child("type").getValue().equals("Barber")) {
                                    Intent intent = new Intent(Login.this, BarberDashboard.class);
                                    intent.putExtra("desiredShopID", dataSnapshot.child(mUsername.getText().toString()).child("desiredShopID").getValue().toString());
                                    startActivity(intent);
                                }
                            }
//                            HashMap<String, Object> dataMap = (HashMap<String, Object>) dataSnapshot.getValue();
//
//                            for (String key : dataMap.keySet()){
//
//                                Object data = dataMap.get(key);
//
//                                try{
//                                    HashMap<String, Object> userData = (HashMap<String, Object>) data;
//
//                                    User mUser = new User((String) userData.get("name"), (int) (long) userData.get("age"));
//                                    addTextToView(mUser.getName() + " - " + Integer.toString(mUser.getAge()));
//
//                                }catch (ClassCastException cce){
//
//// If the object can’t be casted into HashMap, it means that it is of type String.
//
//                                    try{
//
//                                        String mString = String.valueOf(dataMap.get(key));
//                                        addTextToView(mString);
//
//                                    }catch (ClassCastException cce2){
//
//                                    }
//                                }
//
//                            }
                        }
                    }

                    @Override
                    public void onCancelled( DatabaseError databaseError) {

                    }
                });


            }
        });

    }
}
