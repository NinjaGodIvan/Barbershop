package com.example.barbershopapp;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.util.Log;
import android.view.View;
import android.content.Intent;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.Query;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class BarberDashboard extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.barber_dashboard);
        final String shopID = getIntent().getStringExtra("desiredShopID");
        System.out.println(shopID);

        final Button mNextCustomerButton = findViewById(R.id.NextCustomerButton);

                final FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference ref = database.getReference("server/saving-data/BarberShops/" + shopID + "/Waitlist");

// Attach a listener to read the data at our posts reference
                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {


                        mNextCustomerButton.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                DatabaseReference mDatabaseReference = FirebaseDatabase.getInstance().getReference("server/saving-data/BarberShops/" + shopID + "/Waitlist");



                                mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        ArrayList<String> waitlist = new ArrayList<String>();
                                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                            String user = snapshot.getValue(String.class);
                                            waitlist.add(user);
                                        }
                                        System.out.println(waitlist);
                                        //Collections.reverse(waitlist);
                                        waitlist.remove(0);
                                        // Then replace waitlist with new waitlist: maybe do a loop
                                        FirebaseDatabase database2 = FirebaseDatabase.getInstance();
                                        DatabaseReference ref2 = database2.getReference("server/saving-data/BarberShops/" + shopID + "/Waitlist");
                                        ref2.setValue(waitlist);
                                    }


                                    @Override
                                    public void onCancelled( DatabaseError databaseError) {

                                    }
                                });
                            }
                            });


                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        System.out.println("The read failed: " + databaseError.getCode());
                    }
                });




    }
}
