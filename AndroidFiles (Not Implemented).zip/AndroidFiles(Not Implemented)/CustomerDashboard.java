package com.example.barbershopapp;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import android.content.Intent;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.Query;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import android.graphics.Color;
import android.widget.TextView;
import android.content.Context;
import android.view.Gravity;
import android.app.Activity;
import java.util.ArrayList;
import java.util.Collections;

public class CustomerDashboard extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_dashboard);
        final String username = getIntent().getStringExtra("username");

        final Button mSubmitCodeButton = findViewById(R.id.SubmitCode);
        final TextView mCode = findViewById(R.id.barbershop_code);
        final TextView mTitle2 = findViewById(R.id.Title2);
        final TextView mMakeAppointment = findViewById(R.id.MakeAppointment);
        final Button mMakeAppointmentButton = findViewById(R.id.MakeAppointmentButton);
        final TextView mCheckAppointments = findViewById(R.id.CheckAppointments);
        final Button mCheckAppointmentsButton = findViewById(R.id.CheckAppointmentsButton);
        final TextView mEnterWaitlist = findViewById(R.id.EnterWaitlist);
        final Button mEnterWaitlistButton = findViewById(R.id.EnterWaitlistButton);
        final TextView mCheckWaitlistPosition = findViewById(R.id.CheckWaitlistPosition);
        final Button mCheckWaitlistPositionButton = findViewById(R.id.CheckWaitlistPositionButton);
        final TextView mPosition = findViewById(R.id.position);
        final TextView mPositionNumber = findViewById(R.id.positionNumber);
        // Write a message to the database


        mSubmitCodeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                DatabaseReference mBarberShopReference = FirebaseDatabase.getInstance().getReference("server/saving-data/BarberShops");
                mBarberShopReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        // IF code exists on screen and if the code matches a barbershop
                        if (dataSnapshot.child(mCode.getText().toString()).exists()) {
                            DatabaseReference mDatabaseReference = FirebaseDatabase.getInstance().getReference("server/saving-data/BarberShops/" + mCode.getText().toString() + "/Waitlist");



                            mDatabaseReference.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    ArrayList<String> waitlist = new ArrayList<String>();
                                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                        String user = snapshot.getValue(String.class);
                                        waitlist.add(user);
                                    }
                                    if (waitlist.contains(username)) {
                                        mPosition.setText("True");
                                        // Collections.reverse(waitlist);
                                        System.out.println(waitlist);
                                        for (int i = 0; i <waitlist.size(); i++) {
                                            if (waitlist.get(i).equals(username)) {
                                                mPositionNumber.setText(Integer.toString(i));
                                            }
                                        }
                                        if (mPositionNumber.getText().toString().equals("0")) {
                                            Context context = getApplicationContext();
                                            CharSequence text = "It's your turn for a cut! You have 10 minutes to arrive at the Barbershop";
                                            int duration = Toast.LENGTH_LONG;

                                            Toast toast = Toast.makeText(context, text, duration);
                                            toast.setGravity(Gravity.TOP|Gravity.LEFT, 0, 0);
                                            toast.show();
                                        }
                                    } else {
                                        mPosition.setText("False");
                                    }
                                }


                                @Override
                                public void onCancelled( DatabaseError databaseError) {

                                }
                            });
                            mTitle2.setVisibility(View.VISIBLE);
                            mMakeAppointment.setVisibility(View.VISIBLE);
                            mMakeAppointmentButton.setVisibility(View.VISIBLE);
                            mCheckAppointments.setVisibility(View.VISIBLE);
                            mCheckAppointmentsButton.setVisibility(View.VISIBLE);
                            mEnterWaitlist.setVisibility(View.VISIBLE);
                            mEnterWaitlistButton.setVisibility(View.VISIBLE);
                            mEnterWaitlistButton.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v) {


                                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                                    DatabaseReference ref = database.getReference("server/saving-data/BarberShops/" + mCode.getText().toString() + "/Waitlist");
                                    ref.child(username).setValue(username);

                                    Context context = getApplicationContext();
                                    CharSequence text = "You have been added to the waitlist!";
                                    int duration = Toast.LENGTH_SHORT;

                                    Toast toast = Toast.makeText(context, text, duration);
                                    toast.setGravity(Gravity.TOP|Gravity.LEFT, 0, 0);
                                    toast.show();
                                }
                                });
                            mCheckWaitlistPosition.setVisibility(View.VISIBLE);
                            mCheckWaitlistPositionButton.setVisibility(View.VISIBLE);
                            mCheckWaitlistPositionButton.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v) {
                                    if (mPosition.getText().toString().equals("True")) {
                                        Context context = getApplicationContext();
                                        CharSequence text = "You are position: " + mPositionNumber.getText().toString();
                                        int duration = Toast.LENGTH_SHORT;

                                        Toast toast = Toast.makeText(context, text, duration);
                                        toast.setGravity(Gravity.TOP|Gravity.LEFT, 0, 0);
                                        toast.show();
                                    }

                                }
                                });
                        }
                        // If customer's position is 0, notify
                        System.out.println(dataSnapshot.child(username));
                        // if barbershop exists, set container to visible and enable functionalities with barbershop ID code

                    }

                    @Override
                    public void onCancelled( DatabaseError databaseError) {

                    }
                });

            }
            });





    }
}