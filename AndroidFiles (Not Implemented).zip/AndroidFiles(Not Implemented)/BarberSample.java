package com.example.barbershopapp;
import java.io.*;
import java.util.Scanner;

public class BarberSample{
    public String name;
    public String username;
    public String email;
    public Long phone;
    public String password;
    public Long userID;
    public String status;
    public Long desiredShopID;
    public String type;

    BarberSample(Long userID, String type, String username,  String email, Long phone, String password, String status, Long desiredShopID) {
        this.userID = userID;
        this.type = type;
        this.username = username;
        this.email = email;
        this.phone = phone;
        this.password = password;
        //this.status = status;
        this.desiredShopID = desiredShopID;
    }
}
